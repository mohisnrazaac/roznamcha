<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <title><?php echo e(__('roznamcha.app.brand')); ?> — <?php echo e($monthLabel); ?></title>
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; color: #0f172a; padding: 24px; }
        h1, h2 { color: #0f172a; margin-bottom: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { border: 1px solid #cbd5f5; padding: 8px; text-align: left; font-size: 12px; }
        th { background: #e0e7ff; }
        .summary { display: flex; gap: 16px; margin-top: 16px; }
        .card { flex: 1; border: 1px solid #cbd5f5; border-radius: 8px; padding: 12px; }
    </style>
</head>
<body>
    <h1><?php echo e(__('roznamcha.app.brand')); ?> — <?php echo e($monthLabel); ?></h1>
    <p><?php echo e($household?->name ?? 'Personal budget'); ?> • <?php echo e($user->name); ?></p>

    <div class="summary">
        <div class="card">
            <h2><?php echo e(__('roznamcha.kharcha.totals_month')); ?></h2>
            <p><?php echo e(__('roznamcha.commons.currency')); ?> <?php echo e(number_format($data['total'], 2)); ?></p>
        </div>
        <div class="card">
            <h2><?php echo e(__('roznamcha.kharcha.average_daily')); ?></h2>
            <p><?php echo e(__('roznamcha.commons.currency')); ?> <?php echo e(number_format($data['average_daily'], 2)); ?></p>
        </div>
        <div class="card">
            <h2><?php echo e(__('roznamcha.reports.title')); ?></h2>
            <p>
                <?php if(!is_null($data['trend_percent'])): ?>
                    <?php echo e($data['trend_percent'] >= 0 ? '+' : ''); ?><?php echo e($data['trend_percent']); ?>%
                    vs previous month
                <?php else: ?>
                    —
                <?php endif; ?>
            </p>
        </div>
        <div class="card">
            <h2>Projection</h2>
            <p><?php echo e(__('roznamcha.commons.currency')); ?> <?php echo e(number_format($data['projection'], 2)); ?></p>
        </div>
    </div>

    <h2 style="margin-top:24px;">Category Breakdown</h2>
    <table>
        <thead>
            <tr>
                <th><?php echo e(__('roznamcha.commons.category')); ?></th>
                <th><?php echo e(__('roznamcha.commons.amount')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data['breakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row['category']); ?></td>
                    <td><?php echo e(__('roznamcha.commons.currency')); ?> <?php echo e(number_format($row['amount'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/roznamcha/resources/views/reports/survival.blade.php ENDPATH**/ ?>
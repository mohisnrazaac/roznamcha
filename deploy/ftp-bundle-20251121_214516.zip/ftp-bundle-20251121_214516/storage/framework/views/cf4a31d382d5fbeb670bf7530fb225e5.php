<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Roznamcha</title>

        
        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>

        
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
    </head>
    <body class="antialiased bg-gray-50 text-gray-900 min-h-screen">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/roznamcha/resources/views/app.blade.php ENDPATH**/ ?>
/**
 * Placeholder bootstrap file for shared frontend setup.
 * Extend this with HTTP clients or other globals when needed.
 */
export default {};

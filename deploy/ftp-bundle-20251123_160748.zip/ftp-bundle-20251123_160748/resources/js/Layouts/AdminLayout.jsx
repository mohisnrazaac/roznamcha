import React from 'react';
import ControlRoomLayout from './ControlRoomLayout';

export default function AdminLayout(props) {
  return <ControlRoomLayout {...props} />;
}
